public class Main {
    public static void main(String[] args) {
        System.out.println("Поехали!");
        TaskManager manager = new TaskManager();

        // Создание задач
        int taskId1 = manager.createTask(new Task("Task 1", "Description 1", Status.NEW));
        int taskId2 = manager.createTask(new Task("Task 2", "Description 2", Status.NEW));

        // Создание эпиков с подзадачами
        int epicId1 = manager.createEpic(new Epic("Epic 1", "Description Epic 1"));
        int subtask1 = manager.createSubtask(new Subtask("Subtask 1", "Desc 1", Status.NEW, epicId1));
        int subtask2 = manager.createSubtask(new Subtask("Subtask 2", "Desc 2", Status.NEW, epicId1));

        int epicId2 = manager.createEpic(new Epic("Epic 2", "Description Epic 2"));
        int subtask3 = manager.createSubtask(new Subtask("Subtask 3", "Desc 3", Status.NEW, epicId2));

        // Вывод всех задач
        System.out.println("--- INITIAL STATE ---");
        System.out.println("Tasks: " + manager.getAllTasks());
        System.out.println("Epics: " + manager.getAllEpics());
        System.out.println("Subtasks: " + manager.getAllSubtasks());
        System.out.println("Epic 1 Subtasks: " + manager.getSubtasksByEpicId(epicId1));

        // Изменение статусов
        Task updatedTask = manager.getTaskById(taskId1);
        updatedTask.setStatus(Status.IN_PROGRESS);
        manager.updateTask(updatedTask);

        Subtask updatedSubtask = manager.getSubtaskById(subtask1);
        updatedSubtask.setStatus(Status.IN_PROGRESS);
        manager.updateSubtask(updatedSubtask);

        updatedSubtask = manager.getSubtaskById(subtask2);
        updatedSubtask.setStatus(Status.DONE);
        manager.updateSubtask(updatedSubtask);

        updatedSubtask = manager.getSubtaskById(subtask3);
        updatedSubtask.setStatus(Status.DONE);
        manager.updateSubtask(updatedSubtask);

        // Вывод после изменений
        System.out.println("\n--- AFTER STATUS UPDATE ---");
        System.out.println("Tasks: " + manager.getAllTasks());
        System.out.println("Epics: " + manager.getAllEpics());
        System.out.println("Subtasks: " + manager.getAllSubtasks());
        System.out.println("Epic 1 Subtasks: " + manager.getSubtasksByEpicId(epicId1));

        // Удаление задач
        manager.deleteTaskById(taskId2);
        manager.deleteEpicById(epicId2);

        // Финальный вывод
        System.out.println("\n--- AFTER DELETION ---");
        System.out.println("Tasks: " + manager.getAllTasks());
        System.out.println("Epics: " + manager.getAllEpics());
        System.out.println("Subtasks: " + manager.getAllSubtasks());
    }
}